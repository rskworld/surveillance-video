// Project: Surveillance Video Dataset
// Author: Molla Samser
// Website: https://rskworld.in/
// Contact: help@rskworld.in
// Phone: +91 93305 39277
// Address: Nutanhat, Mongolkote, Purba Burdwan, West Bengal, India, 713147

function loadVideo(videoPath) {
    const video = document.getElementById('surveillanceVideo');
    video.src = videoPath;
    video.load();
    video.play();
}

function showTab(tabName) {
    // Hide all tab contents
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(content => {
        content.classList.remove('active');
    });
    
    // Remove active class from all buttons
    const tabButtons = document.querySelectorAll('.tab-btn');
    tabButtons.forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab content
    document.getElementById(tabName).classList.add('active');
    
    // Add active class to clicked button
    event.target.classList.add('active');
}

// Initialize video player
document.addEventListener('DOMContentLoaded', function() {
    const video = document.getElementById('surveillanceVideo');
    
    if (video) {
        video.addEventListener('error', function(e) {
            console.log('Video load error:', e);
            // Handle video loading errors gracefully
        });
    }
});

